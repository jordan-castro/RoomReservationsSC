const SERVER_HOST = "localhost";
const SERVER_PORT = "3001";

export default `http://${SERVER_HOST}:${SERVER_PORT}/`;