# RoomReservations Backend Server

- A local server
- Local database - for faster loading
- Gas fees should be handled by the owner
- UI for rooms, reservations
- Image uplad